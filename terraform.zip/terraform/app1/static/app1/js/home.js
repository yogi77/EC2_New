
function validate() {
    var v1 = document.getElementById("var1").value;
    var v2 = document.getElementById("var2").value;
    var v3 = document.getElementById("var3").value;
    var v4 = document.getElementById("var4").value;
    var v5 = document.getElementById("var5").value;
    var v6 = document.getElementById("var6").value;
    var v7 = document.getElementById("var7").value;
    var v8 = document.getElementById("var8").value;
    var v9 = document.getElementById("var9").value;
    var v10 = document.getElementById("var10").value;
    var v11 = document.getElementById("var11").value;

    
    document.getElementById("var1").style.borderColor = "#ced4da";
    document.getElementById("var2").style.borderColor = "#ced4da";
    document.getElementById("var3").style.borderColor = "#ced4da";
    document.getElementById("var4").style.borderColor = "#ced4da";
    document.getElementById("var5").style.borderColor = "#ced4da";
    document.getElementById("var6").style.borderColor = "#ced4da";
    document.getElementById("var7").style.borderColor = "#ced4da";
    document.getElementById("var8").style.borderColor = "#ced4da";
    document.getElementById("var9").style.borderColor = "#ced4da";
    document.getElementById("var10").style.borderColor = "#ced4da";
    document.getElementById("var11").style.borderColor = "#ced4da";

    var errormsg = "Enter the values for the following : \n";
    if(v1 == "") {
        errormsg += "\nvpc_cidr_block";
        document.getElementById("var1").style.borderColor = "red";
        document.getElementById("var1").style.borderWidth = "2px";
        document.getElementById("var1").focus();
    }
    else if(v2 == "") {
        errormsg += "\npub_sub_cidr";
        document.getElementById("var2").style.borderColor = "red";
        document.getElementById("var2").style.borderWidth = "2px";
        document.getElementById("var2").focus();
    }
    else if(v3 == ""){
        errormsg += "\npvt_sub_cidr";
        document.getElementById("var3").style.borderColor = "red";
        document.getElementById("var3").style.borderWidth = "2px";
        document.getElementById("var3").focus();
    }
    else if(v4 == ""){
        errormsg += "\nroutetable4_cidr_block";
        document.getElementById("var4").style.borderColor = "red";
        document.getElementById("var4").style.borderWidth = "2px";
        document.getElementById("var4").focus();
    }
    else if(v5 == ""){
        errormsg += "\nroutetable2_cidr_block";
        document.getElementById("var5").style.borderColor = "red";
        document.getElementById("var5").style.borderWidth = "2px";
        document.getElementById("var5").focus();
    }
    else if(v6 == ""){
        errormsg += "\nami"
        document.getElementById("var6").style.borderColor = "red";
        document.getElementById("var6").style.borderWidth = "2px";
        document.getElementById("var6").focus();
    }
    else if(v7 == ""){
        errormsg += "\nregion";
        document.getElementById("var7").style.borderColor = "red";
        document.getElementById("var7").style.borderWidth = "2px";
        document.getElementById("var7").focus();
    }
    else if(v8 == ""){
        errormsg += "\ninstance_type";
        document.getElementById("var8").style.borderColor = "red";
        document.getElementById("var8").style.borderWidth = "2px";
        document.getElementById("var8").focus();
    }
    else if(v9 == ""){
        errormsg += "\ntagname";
        document.getElementById("var9").style.borderColor = "red";
        document.getElementById("var9").style.borderWidth = "2px";
        document.getElementById("var9").focus();
    }
    else if(v10 == ""){
        errormsg += "\nebs_volume_size";
        document.getElementById("var10").style.borderColor = "red";
        document.getElementById("var10").style.borderWidth = "2px";
        document.getElementById("var10").focus();
    }
    else if(v11 == ""){
        errormsg += "\nRepository Name";
        document.getElementById("var11").style.borderColor = "red";
        document.getElementById("var11").style.borderWidth = "2px";
        document.getElementById("var11").focus();
    }
        
    // alert(errormsg);

    if(errormsg != "Enter the values for the following : \n") {
        return false;
    }
    else {
        return true;
    }
}