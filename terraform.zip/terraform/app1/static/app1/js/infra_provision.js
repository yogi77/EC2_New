debugger
//Collapse and Expand 
var acc = document.getElementsByClassName("accordion");
var i;
for (i = 0; i < acc.length; i++) {
acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
    panel.style.display = "none";
    } else {
    panel.style.display = "block";
    }
});
}

//Angle Up and Down Arrow Switching
function f1(){
    if(document.getElementById("panel1").style.display == "block") {
        document.getElementById('gd').className = "fas fa-angle-down";
    }
    else {
        document.getElementById('gd').className = "fas fa-angle-up";
        document.getElementById("panel2").style.display = "none";
        document.getElementById("panel3").style.display = "none";
        document.getElementById('id').className = "fas fa-angle-down";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
}
function f2(){
    debugger
    if(document.getElementById("panel2").style.display == "block") {
        document.getElementById('id').className = "fas fa-angle-down";
    }
    else {
        document.getElementById('id').className = "fas fa-angle-up";
        document.getElementById("panel1").style.display = "none";
        document.getElementById("panel3").style.display = "none";
        document.getElementById('gd').className = "fas fa-angle-down";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    if((document.getElementById("gvar1").value =="")&&(document.getElementById("gvar2").value =="")&&(document.getElementById("gvar3").value =="")&&(document.getElementById("gvar4").value =="")&&(document.getElementById("gvar5").value ==""))
    {
        document.getElementById("line1").style.borderLeft ="5px solid grey";
    }
    else 
    {
        document.getElementById("line1").style.borderLeft ="5px solid #ff7e67";
    }
}
function f3(){
    if(document.getElementById("panel3").style.display == "block") {
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else {
        document.getElementById('rd').className = "fas fa-angle-up";
        document.getElementById("panel1").style.display = "none";
        document.getElementById("panel2").style.display = "none";
        document.getElementById('gd').className = "fas fa-angle-down";
        document.getElementById('id').className = "fas fa-angle-down";
        document.getElementById("reviewdata").style.display = "block";
        document.getElementById("submitdiv").style.display = "block";
    }
}

// Fill Deatils
function fillDetails() {
    var str= `<table class="table tableborderless" text-align="left"> <tbody>
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">Application Name</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("gvar1").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">Microservice Name</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("gvar2").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">Email recipient </td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("gvar3").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">Repository Name</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("gvar4").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">Branch Name</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("gvar5").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">vpc_cidr_block value</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("ivar1").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">pub_sub_cidr value</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("ivar2").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">pvt_sub_cidr value</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("ivar3").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">routetable1_cidr_block value</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("ivar4").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">routetable2_cidr_block value</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("ivar5").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">ami value</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("ivar6").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">region value</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("ivar7").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">instance_type value</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("ivar8").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">env value</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("ivar9").value+`</span></td>
    </tr> 
    <tr>
        <td class="labels1" style="border:none;font-weight:700;">ebs_volume_size value</td>
        <td style="border:none;padding: 0px 100px;"><span>`+document.getElementById("ivar10").value+`</span></td>
    </tr> 
    </tbody>
    </table>`;
    document.getElementById("tablecoldiv").innerHTML=str;
}

//Review Data
function reviewValidate() {
    var gv1 = document.getElementById("gvar1");
    var gv2 = document.getElementById("gvar2");
    var gv3 = document.getElementById("gvar3");
    var gv4 = document.getElementById("gvar4");
    var gv5 = document.getElementById("gvar5");
    var iv1 = document.getElementById("ivar1");
    var iv2 = document.getElementById("ivar2");
    var iv3 = document.getElementById("ivar3");
    var iv4 = document.getElementById("ivar4");
    var iv5 = document.getElementById("ivar5");
    var iv6 = document.getElementById("ivar6");
    var iv7 = document.getElementById("ivar7");
    var iv8 = document.getElementById("ivar8");
    var iv9 = document.getElementById("ivar9");
    var iv10 = document.getElementById("ivar10");
    document.getElementById("panel1").style.display = "none";
    document.getElementById("panel2").style.display = "none";
    document.getElementById('gd').className = "fas fa-angle-down";
    document.getElementById('id').className = "fas fa-angle-down";
    if(gv1.value==""){
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
        document.getElementById("panel1").style.display = "block";
        document.getElementById('gd').className = "fas fa-angle-up";
        gv1.focus();
    }
    else if(gv2.value==""){
        document.getElementById("panel1").style.display = "block";
        document.getElementById('gd').className = "fas fa-angle-up";
        gv2.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(gv3.value==""){
        document.getElementById("panel1").style.display = "block";
        document.getElementById('gd').className = "fas fa-angle-up";
        gv3.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(gv4.value==""){
        document.getElementById("panel1").style.display = "block";
        document.getElementById('gd').className = "fas fa-angle-up";
        gv4.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(gv5.value==""){
        document.getElementById("panel1").style.display = "block";
        document.getElementById('gd').className = "fas fa-angle-up";
        gv5.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(iv1.value==""){
        document.getElementById("panel2").style.display = "block";
        document.getElementById('id').className = "fas fa-angle-up";
        iv1.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(iv2.value==""){
        document.getElementById("panel2").style.display = "block";
        document.getElementById('id').className = "fas fa-angle-up";
        iv2.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(iv3.value==""){
        document.getElementById("panel2").style.display = "block";
        document.getElementById('id').className = "fas fa-angle-up";
        iv3.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(iv4.value==""){
        document.getElementById("panel2").style.display = "block";
        document.getElementById('id').className = "fas fa-angle-up";
        iv4.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(iv5.value==""){
        document.getElementById("panel2").style.display = "block";
        document.getElementById('id').className = "fas fa-angle-up";
        iv5.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(iv6.value==""){
        document.getElementById("panel2").style.display = "block";
        document.getElementById('id').className = "fas fa-angle-up";
        iv6.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(iv7.value==""){
        document.getElementById("panel2").style.display = "block";
        document.getElementById('id').className = "fas fa-angle-up";
        iv7.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(iv8.value==""){
        document.getElementById("panel2").style.display = "block";
        document.getElementById('id').className = "fas fa-angle-up";
        iv8.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(iv9.value==""){
        document.getElementById("panel2").style.display = "block";
        document.getElementById('id').className = "fas fa-angle-up";
        iv9.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else if(iv10.value==""){
        document.getElementById("panel2").style.display = "block";
        document.getElementById('id').className = "fas fa-angle-up";
        iv10.focus();
        document.getElementById("panel3").style.display = "none";
        document.getElementById('rd').className = "fas fa-angle-down";
    }
    else {
        f3();
        document.getElementById("step1").style.color="#ff7e67";
        document.getElementById("step1").style.border="5px solid #ff7e67";
        document.getElementById("step1h5").style.color="#ff7e67";
        // document.getElementById("line1").style.borderLeft ="5px solid #ff7e67";
        document.getElementById("step2").style.color="#ff7e67";
        document.getElementById("step2").style.border="5px solid #ff7e67";
        document.getElementById("step2h5").style.color="#ff7e67";
        
        document.getElementById("step3").style.color="#ff7e67";
        document.getElementById("step3").style.border="5px solid #ff7e67";
        document.getElementById("step3h5").style.color="#ff7e67";
        document.getElementById("line2").style.borderLeft ="5px solid #ff7e67";
        fillDetails();
    }
}
