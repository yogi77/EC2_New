from django.db import models
from django.contrib.auth.models import User

# Create your models here.
# class Home(models.Model):
#     var1 = models.ForeignKey("Var1", on_delete)
#     var2 = 
#     var3 = 