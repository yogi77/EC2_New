from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login, name='login'),
    path('verifylogin/', views.verifylogin, name='verifylogin'),
    path('signup/', views.signup, name='signup'),
    path('fetchUsername/', views.fetchUsername, name='fetchUsername'),
    path('saveSignUp/',views.saveSignUp, name="saveSignUp"),
    path('homepage/', views.homepage, name='homepage'),
    path('infra_provision/', views.infra_provision, name='infra_provision'),
    path('input/', views.input, name='input'),
    path('search/', views.search, name='search'),
    path('SaveGitRepo/',views.SaveGitRepo, name="SaveGitRepo"),
]