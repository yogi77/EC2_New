from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic.list import ListView
import base64
import json
from github import Github
from pprint import pprint
from datetime import datetime,timedelta
import pymysql,cgi,os
from git import Repo, RemoteReference
import git
import jenkins
import requests
# from django.core.context_processors import csrf
from django.template.context_processors import csrf
from django.template import RequestContext
from django.views.decorators.csrf import csrf_protect
import xml.etree.ElementTree as ET 
from xml.etree import ElementTree
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DBUsername = "root"
DBPassword = "root123$"
DBServer = "terraformdb.coc82jszdqls.us-east-1.rds.amazonaws.com"                       #"localhost"
DBPort = 3306
DBService = "terraformdb"
form = cgi.FieldStorage()
loginVal = "1"

# Create your views here.
def DBconnection():
    conn=pymysql.connect(user=DBUsername, passwd=DBPassword, host=DBServer, port=DBPort,database=DBService)
    return conn.cursor(),conn

# SIGN UP FUNCTIONS
def signup(request):
    return render(request,"app1/signup.html")

def fetchUsername(request):
    v1 = request.POST.get('uname', False)
    try:
        # FETCH DATA FROM DB
        db = DBconnection()
        conn=db[1]
        cursor=db[0]
        cursor.execute("SELECT USERNAME from SIGNUP_DETAILS")
        unames = []
        flag = 1
        for i in cursor.fetchall():
            unames.append(i[0])
        for j in unames:
            if(v1 == j):
                flag = 0
                break
            else:
                flag = 1
        print("UserName------->"+v1)
        print("UserNames------->"+str(unames))
        print("Flag------>"+str(flag))
    except:
        print("Exception")
        flag = 2
    return HttpResponse(json.dumps(flag),content_type='application/json')
    
def saveSignUp(request):
    email = request.POST.get('email', False)
    username = request.POST.get('username', False)
    password = request.POST.get('pass', False)
    # INSERT DATA TO DB
    db = DBconnection()
    conn=db[1]
    cursor=db[0]
    cursor.execute("INSERT INTO SIGNUP_DETAILS(EMAIL,USERNAME,PASSWORD) VALUES(%s,%s,%s) ",(str(email),str(username),str(password)))
    conn.commit()
    conn.close()
    return render(request, "app1/login.html")

# LOGIN FUNCTIONS
def login(request):
    return render(request,"app1/login.html")

def verifylogin(request):
    print("--------->   INSIDE Verify Login   <--------")
    global loginVal
    username = request.POST.get('uname', False)
    password = request.POST.get('pass', False)
    # username = request.POST['uname']
    # password = request.POST['pass']
    try:
        # FETCH DATA FROM DB
        db = DBconnection()
        conn=db[1]
        cursor=db[0]
        cursor.execute("SELECT PASSWORD from SIGNUP_DETAILS where USERNAME = '"+str(username)+"'")
        passes = []
        flag = 1
        for i in cursor.fetchall():
            passes.append(i[0])
            print("------>"+str(i[0]))
            if(i[0] == password):
                flag = 0
                loginVal = "0"
            else:
                flag = 1
                loginVal = "1"
    except:
        print("Exception")
        flag = 1
        loginVal = "1"
    return HttpResponse(json.dumps(flag),content_type='application/json')

def homepage(request):
    # print("Login Value----->"+loginVal)
    # if(loginVal == "0"):
    #     return render(request,"app1/index.html")
    # elif(loginVal == "1"):
    #     return render(request,"app1/login.html")
    return render(request,"app1/index.html")

def infra_provision(request):
    return render(request,"app1/infra_provision.html")

def input(request):
    return render(request, "app1/input.html")

def search(request):
    return render(request, "app1/search.html")

# def createJob(request):
#     return render(request, "app1/createJob.html")

def SaveGitRepo(request):
    gv1 = request.POST.get('ngvar1', False)
    gv2 = request.POST.get('ngvar2', False)
    gv3 = request.POST.get('ngvar3', False)
    gv4 = request.POST.get('ngvar4', False)
    gv5 = request.POST.get('ngvar5', False)
    iv1 = request.POST.get('nivar1', False)
    iv2 = request.POST.get('nivar2', False)
    iv3 = request.POST.get('nivar3', False)
    iv4 = request.POST.get('nivar4', False)
    iv5 = request.POST.get('nivar5', False)
    iv6 = request.POST.get('nivar6', False)
    iv7 = request.POST.get('nivar7', False)
    iv8 = request.POST.get('nivar8', False)
    iv9 = request.POST.get('nivar9', False)
    iv10 = request.POST.get('nivar10', False)
    variables_dict = {}
    variables_dict['vpc_cidr_block'] = iv1
    variables_dict['pub_sub_cidr'] = iv2
    variables_dict['pvt_sub_cidr'] = iv3
    variables_dict['routetable1_cidr_block'] = iv4
    variables_dict['routetable2_cidr_block'] = iv5
    variables_dict['ami'] = iv6
    variables_dict['region'] = iv7
    variables_dict['instance_type'] = iv8
    variables_dict['tagname'] = iv9
    variables_dict['ebs_volume_size'] = iv10
    variables_dict['repo_name'] = gv4
    valRepo = "https://github.com/yogi77/"+gv4+".git"
    vpc_data = iv1+" "+iv2+" "+iv3+" "+iv4+" "+iv5
    ec2_data = iv6+" "+iv7+" "+iv8+" "+iv9+" "+iv10
    time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # CREATE JOB IN OSS JENKINS
    # if("VPC" in gv4):
    #     jfString = '@Library(\'SharedLibraries\') _\nenv.APPLICATION_NAME = "'+gv1+'"\nenv.MICROSERVICE_NAME = "'+gv2+'"\nenv.EMAIL = "'+gv3+'"\nenv.SCMURL = "'+valRepo+'"\nenv.BRANCH = "'+gv5+'"\nVPCInfraTemplate()'
    # elif("EC2" in gv4):
    jfString = '@Library(\'SharedLibraries\') _\nenv.APPLICATION_NAME = "'+gv1+'"\nenv.MICROSERVICE_NAME = "'+gv2+'"\nenv.EMAIL = "'+gv3+'"\nenv.SCMURL = "'+valRepo+'"\nenv.BRANCH = "'+gv5+'"\nEC2InfraTemplate()'
    
    result1 = createJenkinsJob(jfString,gv1,gv2,gv3,gv4,gv5)
    print("Created Pipeline Job in OSS Jenkins")

    # SAVE FILES IN REPOSITORY
    username = "yogi77"
    g=Github("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")
    user=g.get_user(username)
    try:
        repo=g.get_user(username).get_repo(gv4)  
        # str1 = 'variable "vpc_cidr_block" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv1+'"\n}\n\nvariable "pub_sub_cidr" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv2+'"\n}\n\nvariable "pvt_sub_cidr" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv3+'"\n}\n\nvariable "routetable1_cidr_block" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv4+'"}\n\nvariable "routetable2_cidr_block" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv5+'"}\n\nvariable "ami" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv6+'"\n}\n\nvariable "region" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv7+'"\n}\n\nvariable "instance_type" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv8+'"\n}\n\nvariable "tagname" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv9+'"\n}\n\nvariable "ebs_volume_size" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv10+'"\n}'
        # str2 = '@Library(\'IAC_Library\') _\nenv.APPLICATION_NAME = "'+gv1+'"\nenv.MICROSERVICE_NAME = "'+gv2+'"\nenv.EMAIL = "'+gv3+'"\nenv.SCM_URL = "'+gv4+'"\nenv.BRANCH = "'+gv4+'"\nTemplate()'
        # file1 = repo.get_contents("/main.tf")
        # repo.update_file(file1.path,"Updated main.tf with new values", str1 ,file1.sha, branch=gv5)
        ####str1 = '# Generic variables\nvariable "AWS_Access_Key" {\n    description = "(required) Access key to login in AWS"\n    default = "AKIAVT3J7MX2XH2A4HE6"\n}\n\nvariable "AWS_Secret_Key" {\n    description = "(required) Access key to login in AWS"\n    default = "141T5T0iR/vlc0LnC8n4hKHewwsKyxBgs/o0Q+OC"\n}\n\nvariable "region" {\n  description = "(required ) where this resource will be deployed"\n  default = "'+iv7+'"\n}\n\n# VPC Variables\n\nvariable "vpc_cidr_block" {\n    default = "'+iv1+'"\n    description = "(required) VPC CIDR Block"\n}\n\n#subnet variables\nvariable "pub_sub_cidr" {\n    default = "'+iv2+'"\n    description = "(required) public subnet cidr block "\n}\n\nvariable "pvt_sub_cidr" {\n    default = "'+iv3+'"\n    description = "(required) private subnet cidr block "\n}\n\n# Route table and Association variables\nvariable "rt1-cidr_block" {\n    description = "(required) cidr block for route table1"\n    default = "'+iv4+'"\n}\n\nvariable "rt2-cidr_block" {\n    description = "(required) cidr block for route table1"\n    default = "'+iv5+'"\n}'
        ####str1 = 'variable "name" {\n  description = "My EC2 instance"\n  default="myfirstistace"\n}\n\nvariable "instance_type" {\n  description = "Instacetype"\n  default     = "'+iv8+'"\n}\nvariable "ami" {\n    type="string"\n    default="'+iv6+'"\n}\nvariable "env" {\n  type = "string"\n  default = "'+iv9+'"\n\n\n}\n\nvariable "encrypted"{\n    default="false"\n}\n\nvariable "root_encrypted"{\n    default="false"\n}\n\nvariable "AWS_ACCESS_KEY" {\n  default = "AKIAVT3J7MX2XH2A4HE6"\n\n\n}\nvariable "AWS_SECRET_KEY" {\n  default="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"\n\n\n}\nvariable "owner" {\n  type = "string"\n  default = "sriram"\n\n\n}\n\nvariable "ebs_optimized" {\n  default="false"\n}\nvariable "root_volume_size" {\n  type = "string"\n  default = "30"\n\n\n}\nvariable "root_volume_type" {\n\n\n    default = "gp2"\n}\nvariable "iampolicyname" {\n  default = "ec2policy"\n\n\n}\nvariable "availability_zone" {\n    default = "us-east-1a"\n}variable "map_public_ip_on_launch" {\n  default = "true"\n  \n}\nvariable "iamrolename" {\n  default = "createiamrole"\n\n\n\n}\n\nvariable "description"{\n    type = "map"\n    default = {\n        "ingress_group"=["default ingress group"]\n        "egress-group"=["default egress group"]\n    }\n}\nvariable "enable_dns_hostnames" {\n    default = "true"\n    description = "(Optional) A boolean flag to enable/disable DNS hostnames in the VPC.\nDefaults false."\n\n\n\n\n}\n\nvariable "enable_classiclink" {\n    default = "false"\n    description = "(Optional) A boolean flag to enable/disable ClassicLink for the VPC. Only valid in regions and accounts that support EC2 Classic. See the ClassicLink documentation for more information. Defaults false."\n\n\n\n}\n\nvariable "instance_tenancy" {\n    default = "default"\n\n    description = "(Optional) A tenancy option for instances launched into the VPC. Default is default, which makes your instances shared on the host. Using either of the other options (dedicated or host) costs at least $2/hr."\n\n\n\n}\nvariable "cidr_block" {\n    default = "'+iv1+'"\n}\nvariable "enable_dns_support" {\n    default = "true"\n    description = "(Optional) A boolean flag to enable/disable DNS support in the VPC. Defaults true."\n\n\n}\n\nvariable "subnetcidr_block" {\n    default = "'+iv2+'"\n}\n\nvariable "ebs_volume_type" {\n  default = "gp2"\n  type = "string"\n\n\n\n}\nvariable "ebs_volume_size" {\n  default = "'+iv10+'"\n\n\n\n}\nvariable "instance_count" {\n  default = "1"\n\n\n}\nvariable "subnet_name" {\n  default = "app-ec2-1"\n\n\n}\nvariable "dataclass" {\n  default = "internal"\n\n\n}\nvariable "disable_api_termination" {\n  default = "false"\n\n\n\n}\n\nvariable "cidr_block_vpc" {\n  default = "'+iv1+'"\n\n\n}\nvariable "securitygroupname" {\n  default = "myfirstsecuritygroup"\n\n\n}\n\nvariable "backends3_bucket" {\n  default = "store-terraform-state-poc"\n\n\n}\nvariable "backends3prefix" {\n  default = "dev/myapp/terraform.tfstate"\n\n\n\n}\nvariable "region" {\n  default = "'+iv7+'"\n\n\n\n}\nlocals {\n\n\n\n  tags={\n    Environment=var.env\n    region=var.region\n\n  }\n  iam_role_tags={\n\n\n\n   Environment=var.env\n    region=var.region\n\n\n  }\n  ec2_tags={\n\n\n\n\n    Environment=var.env\n    region=var.region\n\n\n  }\n\n  mysubnet_tags={\n    Environment=var.env\n    region=var.region\n  }\n}'
        str1 = 'variable "name" {\n  description = "My EC2 instance"\n  default="myfirstistace"\n}\n\nvariable "instance_type" {\n  description = "Istacetype"\n  default     = "'+iv8+'"\n}\nvariable "ami" {\n    type="string"\n    default="'+iv6+'"\n}\nvariable "env" {\n  type = "string"\n  default = "'+iv9+'"\n\n\n\n}\n\n\nvariable "encrypted"{\n    default="false"\n}\nvariable "root_encrypted"{\n    default="false"\n}\n\nvariable "AWS_ACCESS_KEY" {\n  default = "AKIAVT3J7MX2XH2A4HE6"\n\n\n\n}\nvariable "AWS_SECRET_KEY" {\n  default="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"\n\n\n\n}\nvariable "owner" {\n  type = "string"\n  default = "sriram"\n\n\n\n}\n\nvariable "ebs_optimized" {\n  default="false"\n}\nvariable "root_volume_size" {\n  type = "string"\n  default = "30"\n\n\n\n\n}\nvariable "root_volume_type" {\n\n\n\n  default = "gp2"\n}\nvariable "iampolicyname" {\n  default = "ec2policy"\n\n\n\n}\nvariable "availability_zone" {\n    default = "us-east-1a"\n}\nvariable "map_public_ip_on_launch" {\n  default = "true"\n\n\n\n}\nvariable "iamrolename" {\n  default = "createiamrole"\n\n\n\n\n}\n\nvariable "description"{\n    type = "map"\n    default = {\n        "ingress_group"=["default ingress group"]\n        "egress-group"=["default egress group"]\n    }\n}\nvariable "enable_dns_hostnames" {\n    default = "true"\n    description = "(Optional) A boolean flag to enable/disable DNS hostnames in the VPC. Defaults false."\n\n\n\n\n\n\n\n}\n\nvariable "enable_classiclink" {\n    default = "false"\n    description = "(Optional) A boolean flag to enable/disable ClassicLink for the VPC. Only valid in regions and accounts that support EC2 Classic. See the ClassicLink documentation for more information. Defaults false."\n\n\n\n\n\n\n\n}\n\nvariable "instance_tenancy" {\n    default = "default"\n    description = "(Optional) A tenancy option for instances launched into the VPC. Default is default, which makes your instances shared on the host. Using either of the other options (dedicated or host) costs at least $2/hr."\n\n\n\n\n\n\n\n}\nvariable "cidr_block" {\n    default = "'+iv1+'"\n}\nvariable "enable_dns_support" {\n    default = "true"\n    description = "(Optional) A boolean flag to enable/disable DNS support in the VPC. Defaults true."\n\n\n\n}\n\nvariable "subnetcidr_block" {\n    default = "'+iv2+'"\n}\n\nvariable "ebs_volume_type" {\n  default = "gp2"\n  type = "string"\n\n\n\n}\nvariable "ebs_volume_size" {\n  default = "'+iv10+'"\n\n\n\n\n}\nvariable "instance_count" {\n  default = "1"\n\n\n\n\n}\nvariable "subnet_name" {\n  default = "app-ec2-1"\n\n\n\n}\n\nvariable "dataclass" {\n  default = "internal"\n\n\n\n}\nvariable "disable_api_termination" {\n  default = "false"\n\n\n\n}\n\nvariable "cidr_block_vpc" {\n  default = "'+iv1+'"\n\n\n\n}\nvariable "securitygroupname" {\n  default = "myfirstsecuritygroup"\n\n\n\n}\n\nvariable "backends3_bucket" {\n  default = "store-terraform-state-poc"\n\n\n\n}\nvariable "backends3prefix" {\n  default = "dev/myapp/terraform.tfstate"\n\n\n\n}\nvariable "region" {\n  default = "'+iv7+'"\n\n\n\n}\nlocals {\n\n\n\n  tags={\n    Environment=var.env\n    region=var.region\n\n  }\n  iam_role_tags={\n\n\n\n\n\n    Environment=var.env\n    region=var.region\n\n\n  }\n  ec2_tags={\n\n\n\n\n\n    Environment=var.env\n    region=var.region\n\n\n  }\n\n  mysubnet_tags={\n    Environment=var.env\n    region=var.region\n  }\n}'
        file2 = repo.get_contents("/variables.tf")
        repo.update_file(file2.path,"Updated variables.tf with new values", str1 ,file2.sha)
        # repo.update_file(file2.path,"Updated variables.tf with new values", str1 ,file2.sha, branch=gv5)
        # file3 = repo.get_contents("/JenkinsFile")
        # repo.update_file(file3.path,"Updated JenkinsFile", str2 ,file3.sha, branch=gv5)
    except:                                         #create_repo/create_branch
        repo=g.get_user().create_repo(gv4)   
        # str1 = 'variable "vpc_cidr_block" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv1+'"\n}\n\nvariable "pub_sub_cidr" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv2+'"\n}\n\nvariable "pvt_sub_cidr" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv3+'"\n}\n\nvariable "routetable1_cidr_block" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv4+'"}\n\nvariable "routetable2_cidr_block" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv5+'"}\n\nvariable "ami" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv6+'"\n}\n\nvariable "region" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv7+'"\n}\n\nvariable "instance_type" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv8+'"\n}\n\nvariable "tagname" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv9+'"\n}\n\nvariable "ebs_volume_size" {\ndescription = "Name to be used on all resources as prefix"\ntype        = string\ndefault     = "'+iv10+'"\n}'
        # str2 = '@Library(\'IAC_Library\') _\nenv.APPLICATION_NAME = "'+gv1+'"\nenv.MICROSERVICE_NAME = "'+gv2+'"\nenv.EMAIL = "'+gv3+'"\nenv.SCM_URL = "'+gv4+'"\nenv.BRANCH = "'+gv4+'"\nTemplate()'
        # file1 = repo.get_contents("/main.tf")/6
        # repo.create_file("main.tf","Added main.tf with new values", str1, branch=gv5)
        # file2 = repo.get_contents("/variables.tf")
        repo.create_file("variables.tf","Added variables.tf with new values", str1, branch=gv5)
        # repo.create_file("JenkinsFile","Added JenkinsFile", str2, branch=gv5)
    
    # INSERT DATA TO DB
    uname = "User"
    db = DBconnection()
    conn=db[1]
    cursor=db[0]
    cursor.execute("INSERT INTO INPUT_DETAILS(APPLICATION,MICROSERVICE,EMAIL,REPO_NAME,BRANCH_NAME,USERNAME,VPCDETAILS,EC2DETAILS) VALUES(%s,%s,%s,%s,%s,%s,%s,%s) ",(str(gv1),str(gv2),str(gv3),str(gv4),str(gv5),str(uname),str(vpc_data),str(ec2_data)))
    conn.commit()
    conn.close()
    
    jenkinslink = "http://34.234.170.162:8080/job/"+gv1+"/job/"+gv2+"/job/EC2_Infra_Job/"   #34.227.101.148:8080
    githublink = "https://github.com/"+"yogi77"+"/"+str(gv4)
    return render(request,"app1/SaveGitRepo.html",{"githublink":githublink,"jenkinslink":jenkinslink})

def createJenkinsJob(jfString,gv1,gv2,gv3,gv4,gv5):
    try:
        server = jenkins.Jenkins('http://34.234.170.162:8080', username='admin', password='admin')            #http://34.227.101.148:8080
        jobs = server.get_jobs()
        print("---------->"+str(jobs))
        foldertree = xmlread('config_folder.xml')
        pipelineJob = xmlread('config_job.xml')
        pipelineJob.find("definition")[0].text = jfString
        pipelinexml = ElementTree.tostring(pipelineJob).decode('utf-8')
        folderxml = ElementTree.tostring(foldertree).decode('utf-8')
        appFolder = gv1.replace(" ","-")                #"IAC_PIPELINES/"
        compFolder = gv1.replace(" ","-")+"/"+gv2.replace(" ","-")
        pipelinePath = gv1.replace(" ","-")+"/"+gv2.replace(" ","-")+"/EC2_Infra_Job"
        server.create_job(appFolder, folderxml)
        server.create_job(compFolder, folderxml)
        server.create_job(pipelinePath, pipelinexml)
        return 1
    except:
        print("Failed to create the Job in Jenkins Server")
        return 0

# def crumb(core,username,password):
#     req = requests.get(core+'/crumbIssuer/api/xml?path=concat(//crumbRequestField,":",//crumb)', auth=(username, password), verify=False)
#     return req.text[14:]

def xmlread(filename):
    xmldata = open(BASE_DIR+"/app1/"+str(filename),"r")
    data = ET.fromstring(xmldata.read())
    return data